/**
 * Test for normalize.
 * Copyright 2017 MPI-CBG/MPI-PKS Peter Schwede
 */

#include <criterion/criterion.h>
#include <math.h>

#include "HMM.h"
#include "Logging.h"
#include "EmissionTable.h"

